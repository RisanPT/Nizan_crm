import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models/employee.dart';
import '../core/models/salary_increment.dart';
import '../core/models/list_page_params.dart';
import '../core/models/paginated_list_response.dart';
import '../providers/dio_provider.dart';

import '../core/auth/app_role.dart';
import '../core/providers/auth_provider.dart';

final employeeServiceProvider = Provider<EmployeeService>((ref) {
  return EmployeeService(ref.watch(dioProvider));
});

final employeesProvider = FutureProvider<List<Employee>>((ref) async {
  return ref.watch(employeeServiceProvider).getEmployees();
});

final paginatedEmployeesProvider =
    FutureProvider.family<PaginatedListResponse<Employee>, ListPageParams>((
      ref,
      params,
    ) async {
      final authSession = ref.watch(authSessionProvider);
      final role = AppRole.fromString(authSession?.role);
      
      var zoneId = params.zoneId;
      var stateId = params.stateId;
      var regionId = params.regionId;
      var districtId = params.districtId;
      var pincodeId = params.pincodeId;

      if (!role.isFullAccess) {
        if (authSession != null) {
          if (authSession.zoneId.isNotEmpty) zoneId = authSession.zoneId;
          if (authSession.stateId.isNotEmpty) stateId = authSession.stateId;
          if (authSession.regionId.isNotEmpty) regionId = authSession.regionId;
          if (authSession.districtId.isNotEmpty) districtId = authSession.districtId;
          if (authSession.pincodeId.isNotEmpty) pincodeId = authSession.pincodeId;
        }
      }

      return ref.watch(employeeServiceProvider).getPaginatedEmployees(
            page: params.page,
            limit: params.limit,
            category: params.category,
            department: params.department,
            artistRole: params.artistRole,
            search: params.search,
            zoneId: zoneId,
            stateId: stateId,
            regionId: regionId,
            districtId: districtId,
            pincodeId: pincodeId,
          );
    });

class EmployeeService {
  final Dio _dio;

  EmployeeService(this._dio);

  Future<List<Employee>> getEmployees() async {
    try {
      final response = await _dio.get('/employees');
      final data = response.data;
      
      List employeesList;
      if (data is Map) {
        employeesList = (data['data'] ?? data['items'] ?? data['employees'] ?? []) as List;
      } else if (data is List) {
        employeesList = data;
      } else {
        employeesList = [];
      }
      
      return employeesList
          .map((item) => Employee.fromJson(item as Map<String, dynamic>))
          .toList();
    } on DioException catch (e) {
      throw Exception('Failed to load employees: ${e.message}');
    }
  }

  Future<Employee> getEmployeeById(String id) async {
    try {
      final response = await _dio.get('/employees/$id');
      return Employee.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw Exception('Failed to load employee: ${e.message}');
    }
  }

  Future<PaginatedListResponse<Employee>> getPaginatedEmployees({
    int page = 1,
    int limit = 20,
    String? category,
    String? department,
    String? artistRole,
    String? search,
    String? zoneId,
    String? stateId,
    String? regionId,
    String? districtId,
    String? pincodeId,
  }) async {
    try {
      final Map<String, dynamic> queryParams = {
        'page': page,
        'limit': limit,
        if (category != null && category.isNotEmpty) 'category': category,
        if (department != null && department.isNotEmpty && department != 'All') 'department': department,
        if (artistRole != null && artistRole.isNotEmpty && artistRole != 'All') 'artistRole': artistRole,
        if (search != null && search.isNotEmpty) 'search': search,
        if (zoneId != null && zoneId.isNotEmpty) 'zoneId': zoneId,
        if (stateId != null && stateId.isNotEmpty) 'stateId': stateId,
        if (regionId != null && regionId.isNotEmpty) 'regionId': regionId,
        if (districtId != null && districtId.isNotEmpty) 'districtId': districtId,
        if (pincodeId != null && pincodeId.isNotEmpty) 'pincodeId': pincodeId,
      };
      final response = await _dio.get(
        '/employees',
        queryParameters: queryParams,
      );
      return PaginatedListResponse.fromJson(
        response.data as Map<String, dynamic>,
        Employee.fromJson,
      );
    } on DioException catch (e) {
      throw Exception('Failed to load employees: ${e.message}');
    }
  }

  Future<Employee> saveEmployee({
    String? id,
    required String name,
    required String email,
    required String type,
    required String artistRole,
    required String specialization,
    required String phone,
    required String status,
    required String regionId,
    required String category,
    String? department,
    String? role,
    List<String>? works,
    String? profileImage,
    String? zoneId,
    String? stateId,
    String? districtId,
    String? pincodeId,
    String? salaryType,
    double? baseSalary,
    double? allowances,
    double? deductions,
    String? bankName,
    String? accountNumber,
    String? ifscCode,
    String? upiId,
    String? panNumber,
  }) async {
    try {
      final payload = {
        'name': name,
        'email': email,
        'type': type,
        'artistRole': artistRole,
        'specialization': specialization,
        'phone': phone,
        'status': status,
        'regionId': regionId,
        'category': category,
        if (department != null && department.isNotEmpty) 'department': department,
        if (role != null && role.isNotEmpty) 'role': role,
        'works': ?works,
        if (zoneId != null && zoneId.isNotEmpty) 'zoneId': zoneId,
        if (stateId != null && stateId.isNotEmpty) 'stateId': stateId,
        if (districtId != null && districtId.isNotEmpty) 'districtId': districtId,
        if (pincodeId != null && pincodeId.isNotEmpty) 'pincodeId': pincodeId,
        'salaryType': ?salaryType,
        'baseSalary': ?baseSalary,
        'allowances': ?allowances,
        'deductions': ?deductions,
        'bankName': ?bankName,
        'accountNumber': ?accountNumber,
        'ifscCode': ?ifscCode,
        'upiId': ?upiId,
        'panNumber': ?panNumber,
      };

      if (profileImage != null) {
        payload['profileImage'] = profileImage;
      }

      final response = id != null && id.isNotEmpty
          ? await _dio.put('/employees/$id', data: payload)
          : await _dio.post('/employees', data: payload);

      return Employee.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      String errorMessage = 'Failed to save employee: ${e.message}';
      if (e.response != null && e.response!.data != null) {
        final data = e.response!.data;
        if (data is Map && data['message'] != null) {
          errorMessage = data['message'].toString();
        }
      }
      throw Exception(errorMessage);
    }
  }

  Future<void> deleteEmployee(String id) async {
    try {
      await _dio.delete('/employees/$id');
    } on DioException catch (e) {
      throw Exception('Failed to delete employee: ${e.message}');
    }
  }

  Future<List<SalaryIncrement>> getIncrements(String employeeId) async {
    try {
      final response = await _dio.get('/employees/$employeeId/increments');
      final data = response.data as List;
      return data.map((item) => SalaryIncrement.fromJson(item as Map<String, dynamic>)).toList();
    } on DioException catch (e) {
      throw Exception('Failed to load increments: ${e.message}');
    }
  }

  Future<SalaryIncrement> addIncrement(String employeeId, {required double newSalary, required String reason, DateTime? effectiveDate}) async {
    try {
      final response = await _dio.post('/employees/$employeeId/increments', data: {
        'newSalary': newSalary,
        'reason': reason,
        if (effectiveDate != null) 'effectiveDate': effectiveDate.toIso8601String(),
      });
      return SalaryIncrement.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw Exception('Failed to add increment: ${e.message}');
    }
  }
}
