import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../core/extensions/space_extension.dart';
import '../../core/auth/access_control.dart';
import '../../services/role_service.dart';
import '../../core/models/crm_user.dart';
import '../../core/models/list_page_params.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/crm_theme.dart';
import '../../core/utils/responsive_builder.dart';
import '../common_widgets/paginated_footer.dart';
import '../../services/employee_service.dart';
import '../../services/user_service.dart';
import '../../services/zone_service.dart';
import '../../services/state_service.dart';
import '../../services/region_service.dart';
import '../../services/district_service.dart';
import '../../services/pincode_service.dart';

class SettingsScreen extends HookConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final crmColors = context.crmColors;
    final pageState = useState(1);
    const pageSize = 20;
    final asyncUsers = ref.watch(
      paginatedCrmUsersProvider(
        ListPageParams(page: pageState.value, limit: pageSize),
      ),
    );
    final auth = ref.read(authControllerProvider);
    final session = ref.watch(authSessionProvider);
    final access = Access.of(session);
    final isMobile = ResponsiveBuilder.isMobile(context);
    // ✅ Watched at build level — valid Riverpod usage
    final asyncEmployees = ref.watch(employeesProvider);
    final asyncZones = ref.watch(zonesProvider);
    final asyncStates = ref.watch(statesProvider);
    final asyncRegions = ref.watch(regionsProvider);
    final asyncDistricts = ref.watch(districtsProvider);
    final asyncPincodes = ref.watch(pincodesProvider);

    Future<void> openUserDialog([CrmUser? user]) async {
      final nameCtrl = TextEditingController(text: user?.name ?? '');
      final emailCtrl = TextEditingController(text: user?.email ?? '');
      final passwordCtrl = TextEditingController();
      var role = user?.role ?? 'manager';
      var active = user?.active ?? true;
      var inventoryAccess = user?.inventoryAccess ?? false;
      var isDepartmentHead = user?.isDepartmentHead ?? false;
      var selEmployeeId = user?.employeeId ?? '';
      var selZoneId = user?.zoneId ?? '';
      var selStateId = user?.stateId ?? '';
      var selRegionId = user?.regionId ?? '';
      var selDistrictId = user?.districtId ?? '';
      var selPincodeId = user?.pincodeId ?? '';

      await showDialog(
        context: context,
        builder: (dialogContext) {
          return StatefulBuilder(
            builder: (context, setState) {
              // employees already fetched at build level — safe to use here
              final employees = asyncEmployees.value ?? [];
              employees
                  .where((e) => e.artistRole != 'driver')
                  .toList();
                  
              final zones = asyncZones.value ?? [];
              final allStates = asyncStates.value ?? [];
              final allRegions = asyncRegions.value ?? [];
              final allDistricts = asyncDistricts.value ?? [];
              final allPincodes = asyncPincodes.value ?? [];

              final filteredStates = selZoneId.isEmpty ? allStates : allStates.where((s) => s.zoneId == selZoneId).toList();
              final filteredRegions = selStateId.isEmpty ? allRegions : allRegions.where((r) => r.stateId == selStateId).toList();
              final filteredDistricts = selRegionId.isEmpty ? allDistricts : allDistricts.where((d) => d.regionId == selRegionId).toList();
              final filteredPincodes = selDistrictId.isEmpty ? allPincodes : allPincodes.where((p) => p.districtId == selDistrictId).toList();

              return AlertDialog(
                title: Text(user == null ? 'Add System User' : 'Edit System User'),
                content: SizedBox(
                  width: 460,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ── Basic Info ──────────────────────────────────────
                        TextField(
                          controller: nameCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Full Name *',
                            prefixIcon: Icon(Icons.person_outline),
                          ),
                        ),
                        16.h,
                        TextField(
                          controller: emailCtrl,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Email (login) *',
                            prefixIcon: Icon(Icons.email_outlined),
                          ),
                        ),
                        16.h,
                        TextField(
                          controller: passwordCtrl,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: user == null
                                ? 'Password *'
                                : 'New Password (leave blank to keep)',
                            prefixIcon: const Icon(Icons.lock_outline),
                          ),
                        ),
                        16.h,

                        // ── Role ────────────────────────────────────────────
                        // Roles are configured in Settings → Roles &
                        // Permissions, so this list is driven by the Role
                        // collection rather than a hard-coded set.
                        // For Department Heads (non-full-access), the list is
                        // further scoped to only their creatableRoles.
                        Consumer(
                          builder: (context, ref, _) {
                            final rolesAsync = ref.watch(rolesProvider);
                            final allRoles = rolesAsync.value ?? const [];
                            final creatableKeys = access.creatableRoles;
                            // Empty creatableRoles = admin/manager = no filter
                            final roles = creatableKeys.isEmpty
                                ? allRoles
                                : allRoles
                                    .where((r) => creatableKeys.contains(r.key))
                                    .toList();
                            final values =
                                roles.map((r) => r.key).toSet();
                            return DropdownButtonFormField<String>(
                          initialValue: values.contains(role) ? role : null,
                          isExpanded: true,
                          decoration: InputDecoration(
                            labelText: 'Role *',
                            prefixIcon: const Icon(Icons.badge_outlined),
                            helperText: rolesAsync.isLoading
                                ? 'Loading roles…'
                                : '${roles.length} roles available',
                          ),
                          items: [
                            for (final r in roles)
                              DropdownMenuItem(
                                value: r.key,
                                child: _RoleItem(
                                  label: r.label,
                                  sub: r.permissions.isEmpty
                                      ? 'No features assigned yet'
                                      : '${r.permissions.length} features',
                                  color: _roleColor(r.key),
                                ),
                              ),
                          ],
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                role = value;
                              });
                            }
                          },
                            );
                          },
                        ),

                        // ── Inventory access (artists only) ─────────────────
                        if (role == 'artist') ...[
                          8.h,
                          Container(
                            decoration: BoxDecoration(
                              color: crmColors.secondary.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: crmColors.border),
                            ),
                            child: SwitchListTile(
                              value: inventoryAccess,
                              onChanged: (v) =>
                                  setState(() => inventoryAccess = v),
                              title: const Text('Access to Inventory'),
                              subtitle: const Text(
                                  'Let this artist manage & upload their own inventory',
                                  style: TextStyle(fontSize: 12)),
                              secondary:
                                  const Icon(Icons.inventory_2_outlined),
                            ),
                          ),
                        ],

                        // ── Department Head toggle ───────────────────────────
                        // Settings is already admin/manager-only at the route
                        // level, so no extra isFullAccess guard is needed here.
                        if (role != 'artist') ...[
                          8.h,
                          Container(
                            decoration: BoxDecoration(
                              color: crmColors.accent.withValues(alpha: 0.08),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: isDepartmentHead
                                      ? crmColors.accent
                                      : crmColors.border),
                            ),
                            child: SwitchListTile(
                              value: isDepartmentHead,
                              onChanged: (v) =>
                                  setState(() => isDepartmentHead = v),
                              title: const Text('Department Head'),
                              subtitle: const Text(
                                  'Allows this user to add & manage staff in their own department',
                                  style: TextStyle(fontSize: 12)),
                              secondary: const Icon(
                                  Icons.manage_accounts_outlined),
                            ),
                          ),
                        ],

                        // ── Employee link ────────────
                        16.h,
                        if (asyncEmployees.isLoading)
                          const LinearProgressIndicator()
                        else if (asyncEmployees.hasError)
                          const Text('Could not load employees')
                        else
                          DropdownButtonFormField<String>(
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Link to Employee Profile (Optional)',
                              prefixIcon: Icon(Icons.link_outlined),
                              helperText:
                                  'Connects user to an employee profile for geographic limits',
                            ),
                            initialValue: selEmployeeId.isEmpty ? null : selEmployeeId,
                            // Selected display stays single-line so the 2-line
                            // menu items don't overflow the form field.
                            selectedItemBuilder: (context) => employees
                                .map(
                                  (e) => Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      e.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            items: employees
                                .map(
                                  (e) => DropdownMenuItem(
                                    value: e.id,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(e.name),
                                        Text(
                                          e.specialization.isNotEmpty
                                              ? e.specialization
                                              : e.artistRole,
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) =>
                                setState(() => selEmployeeId = v ?? ''),
                          ),

                        16.h,
                        // ── Geographic Limits ───────────────────────────────
                        const Text('Geographic Access', style: TextStyle(fontWeight: FontWeight.bold)),
                        const Text('Assign geographic limits to this user. Leave empty for unrestricted access.', style: TextStyle(fontSize: 12, color: Colors.grey)),
                        8.h,
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(labelText: 'Zone Limit', prefixIcon: Icon(Icons.map_outlined)),
                          initialValue: selZoneId.isEmpty ? null : selZoneId,
                          items: [
                            const DropdownMenuItem(value: '', child: Text('No Zone Limit')),
                            ...zones.map((z) => DropdownMenuItem(value: z.id, child: Text(z.name))),
                          ],
                          onChanged: (v) {
                            setState(() {
                              selZoneId = v ?? '';
                              selStateId = '';
                              selRegionId = '';
                              selDistrictId = '';
                              selPincodeId = '';
                            });
                          },
                        ),
                        16.h,
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(labelText: 'State Limit', prefixIcon: Icon(Icons.map_outlined)),
                          initialValue: selStateId.isEmpty ? null : selStateId,
                          items: [
                            const DropdownMenuItem(value: '', child: Text('No State Limit')),
                            ...filteredStates.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))),
                          ],
                          onChanged: (v) {
                            setState(() {
                              selStateId = v ?? '';
                              selRegionId = '';
                              selDistrictId = '';
                              selPincodeId = '';
                            });
                          },
                        ),
                        16.h,
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(labelText: 'Region Limit', prefixIcon: Icon(Icons.map_outlined)),
                          initialValue: selRegionId.isEmpty ? null : selRegionId,
                          items: [
                            const DropdownMenuItem(value: '', child: Text('No Region Limit')),
                            ...filteredRegions.map((r) => DropdownMenuItem(value: r.id, child: Text(r.name))),
                          ],
                          onChanged: (v) {
                            setState(() {
                              selRegionId = v ?? '';
                              selDistrictId = '';
                              selPincodeId = '';
                            });
                          },
                        ),
                        16.h,
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(labelText: 'District Limit', prefixIcon: Icon(Icons.map_outlined)),
                          initialValue: selDistrictId.isEmpty ? null : selDistrictId,
                          items: [
                            const DropdownMenuItem(value: '', child: Text('No District Limit')),
                            ...filteredDistricts.map((d) => DropdownMenuItem(value: d.id, child: Text(d.name))),
                          ],
                          onChanged: (v) {
                            setState(() {
                              selDistrictId = v ?? '';
                              selPincodeId = '';
                            });
                          },
                        ),
                        16.h,
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(labelText: 'Pincode Limit', prefixIcon: Icon(Icons.map_outlined)),
                          initialValue: selPincodeId.isEmpty ? null : selPincodeId,
                          items: [
                            const DropdownMenuItem(value: '', child: Text('No Pincode Limit')),
                            ...filteredPincodes.map((p) => DropdownMenuItem(value: p.id, child: Text(p.code))),
                          ],
                          onChanged: (v) {
                            setState(() {
                              selPincodeId = v ?? '';
                            });
                          },
                        ),
                        16.h,

                        // ── Active toggle ───────────────────────────────────
                        SwitchListTile(
                          value: active,
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Active Access'),
                          subtitle: const Text(
                            'Inactive users cannot log in.',
                          ),
                          onChanged: (value) => setState(() => active = value),
                        ),
                      ],
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(dialogContext).pop(),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      final name = nameCtrl.text.trim();
                      final email = emailCtrl.text.trim();
                      final password = passwordCtrl.text.trim();
                      final emailRegex =
                          RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

                      if (name.isEmpty || email.isEmpty) {
                        _showMessage(context, 'Name and email are required');
                        return;
                      }
                      if (!emailRegex.hasMatch(email)) {
                        _showMessage(context, 'Enter a valid email address');
                        return;
                      }
                      if (user == null && password.isEmpty) {
                        _showMessage(
                            context, 'Password is required for new users');
                        return;
                      }
                      if (role == 'artist' && selEmployeeId.isEmpty) {
                        _showMessage(
                            context,
                            'Please link this user to an Employee profile');
                        return;
                      }

                      try {
                        final service = ref.read(userServiceProvider);
                        if (user == null) {
                          await service.createUser(
                            name: name,
                            email: email,
                            password: password,
                            role: role,
                            active: active,
                            inventoryAccess: inventoryAccess,
                            isDepartmentHead: isDepartmentHead,
                            employeeId:
                                selEmployeeId.isEmpty ? null : selEmployeeId,
                            zoneId: selZoneId.isEmpty ? null : selZoneId,
                            stateId: selStateId.isEmpty ? null : selStateId,
                            regionId: selRegionId.isEmpty ? null : selRegionId,
                            districtId: selDistrictId.isEmpty ? null : selDistrictId,
                            pincodeId: selPincodeId.isEmpty ? null : selPincodeId,
                          );
                        } else {
                          await service.updateUser(
                            id: user.id,
                            name: name,
                            email: email,
                            role: role,
                            active: active,
                            inventoryAccess: inventoryAccess,
                            isDepartmentHead: isDepartmentHead,
                            password: password.isEmpty ? null : password,
                            employeeId:
                                selEmployeeId.isEmpty ? null : selEmployeeId,
                            zoneId: selZoneId.isEmpty ? null : selZoneId,
                            stateId: selStateId.isEmpty ? null : selStateId,
                            regionId: selRegionId.isEmpty ? null : selRegionId,
                            districtId: selDistrictId.isEmpty ? null : selDistrictId,
                            pincodeId: selPincodeId.isEmpty ? null : selPincodeId,
                          );
                        }

                        ref.invalidate(crmUsersProvider);
                        ref.invalidate(paginatedCrmUsersProvider);
                        if (!dialogContext.mounted) return;
                        Navigator.of(dialogContext).pop();
                      } catch (error) {
                        if (!dialogContext.mounted) return;
                        _showMessage(
                          dialogContext,
                          error
                              .toString()
                              .replaceFirst('Exception: ', ''),
                        );
                      }
                    },
                    child: Text(user == null ? 'Create User' : 'Save Changes'),
                  ),
                ],
              );
            },
          );
        },
      );
    }

    Future<void> deleteUser(CrmUser user) async {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Delete User'),
          content: Text('Are you sure you want to delete ${user.name}? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: crmColors.destructive,
                foregroundColor: Colors.white,
              ),
              child: const Text('Delete'),
            ),
          ],
        ),
      );

      if (confirm == true) {
        try {
          await ref.read(userServiceProvider).deleteUser(user.id);
          ref.invalidate(crmUsersProvider);
          ref.invalidate(paginatedCrmUsersProvider);
          if (context.mounted) {
            _showMessage(context, 'User deleted successfully');
          }
        } catch (e) {
          if (context.mounted) {
            _showMessage(context, 'Failed to delete user: $e');
          }
        }
      }
    }

    return SelectionArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Settings & Access',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            8.h,
            Text(
              'Manage who can log in to the CRM and sign out from this device.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: crmColors.textSecondary,
              ),
            ),
            24.h,
            _SettingsCard(
              title: 'Session',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Signed in as ${session?.email ?? ''}',
                    style: theme.textTheme.bodyMedium,
                  ),
                  16.h,
                  ElevatedButton.icon(
                    onPressed: () async {
                      await auth.logout();
                    },
                    icon: const Icon(Icons.logout),
                    label: const Text('Logout From This Device'),
                  ),
                ],
              ),
            ),
            24.h,
            _SettingsCard(
              title: 'CRM Users',
              trailing: ElevatedButton.icon(
                onPressed: () => openUserDialog(),
                icon: const Icon(Icons.person_add_alt_1, size: 18),
                label: const Text('Add User'),
              ),
              child: asyncUsers.when(
                data: (response) {
                  final users = response.items;
                  if (users.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 24),
                      child: Text('No CRM users found yet.'),
                    );
                  }
      
                  if (isMobile) {
                    return Column(
                      children: [
                        ...users.map((user) => _MobileUserCard(
                              user: user,
                              currentUserId: session?.userId ?? '',
                              showDelete: session?.role == 'admin' && user.id != session?.userId,
                              onEdit: () => openUserDialog(user),
                              onDelete: () => deleteUser(user),
                            )),
                        16.h,
                        PaginatedFooter(
                          page: response.page,
                          limit: response.limit,
                          totalPages: response.totalPages,
                          totalItems: response.totalItems,
                          currentItemCount: response.items.length,
                          onPrevious: response.page > 1
                              ? () => pageState.value -= 1
                              : null,
                          onNext: response.page < response.totalPages
                              ? () => pageState.value += 1
                              : null,
                        ),
                      ],
                    );
                  }
      
                  return Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: _HeaderText('User'),
                          ),
                          Expanded(
                            flex: 2,
                            child: _HeaderText('Role'),
                          ),
                          Expanded(
                            flex: 2,
                            child: _HeaderText('Linked Employee'),
                          ),
                          Expanded(
                            flex: 2,
                            child: _HeaderText('Status'),
                          ),
                          Expanded(
                            flex: 2,
                            child: _HeaderText('Actions', alignEnd: true),
                          ),
                        ],
                      ),
                      12.h,
                      const Divider(height: 1),
                      ...users.map(
                        (user) => _DesktopUserRow(
                          user: user,
                          currentUserId: session?.userId ?? '',
                          showDelete: session?.role == 'admin' && user.id != session?.userId,
                          onEdit: () => openUserDialog(user),
                          onDelete: () => deleteUser(user),
                        ),
                      ),
                      16.h,
                      PaginatedFooter(
                        page: response.page,
                        limit: response.limit,
                        totalPages: response.totalPages,
                        totalItems: response.totalItems,
                        currentItemCount: response.items.length,
                        onPrevious: response.page > 1
                            ? () => pageState.value -= 1
                            : null,
                        onNext: response.page < response.totalPages
                            ? () => pageState.value += 1
                            : null,
                      ),
                    ],
                  );
                },
                loading: () => const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (error, _) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 24),
                  child: Text(
                    'Failed to load CRM users: $error',
                    style: TextStyle(color: crmColors.destructive),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static void _showMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  const _SettingsCard({
    required this.title,
    required this.child,
    this.trailing,
  });

  final String title;
  final Widget child;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final crmColors = context.crmColors;

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: crmColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: crmColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  title,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (trailing != null) ...[trailing!],
            ],
          ),
          20.h,
          child,
        ],
      ),
    );
  }
}

class _HeaderText extends StatelessWidget {
  const _HeaderText(this.text, {this.alignEnd = false});

  final String text;
  final bool alignEnd;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: alignEnd ? Alignment.centerRight : Alignment.centerLeft,
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
              color: context.crmColors.textSecondary,
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}

class _DesktopUserRow extends StatelessWidget {
  const _DesktopUserRow({
    required this.user,
    required this.currentUserId,
    required this.showDelete,
    required this.onEdit,
    required this.onDelete,
  });

  final CrmUser user;
  final String currentUserId;
  final bool showDelete;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: context.crmColors.border),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.name,
                    style: Theme.of(context).textTheme.titleSmall),
                4.h,
                Text(
                  user.email,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: context.crmColors.textSecondary,
                      ),
                ),
              ],
            ),
          ),
          Expanded(flex: 2, child: _RoleBadge(role: user.role)),
          Expanded(
            flex: 2,
            child: user.employeeId.isNotEmpty
                ? Row(
                    children: [
                      const Icon(Icons.link, size: 14, color: Colors.green),
                      4.w,
                      Flexible(
                        child: Text(
                          'Linked',
                          style: TextStyle(
                              color: Colors.green.shade700, fontSize: 12),
                        ),
                      ),
                    ],
                  )
                : Text('—',
                    style: TextStyle(
                        color: context.crmColors.textSecondary)),
          ),
          Expanded(
            flex: 2,
            child: _StatusChip(active: user.active),
          ),
          Expanded(
            flex: 2,
            child: Align(
              alignment: Alignment.centerRight,
              child: Wrap(
                spacing: 8,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if (user.id == currentUserId) const Chip(label: Text('You')),
                  OutlinedButton(
                    onPressed: onEdit,
                    child: const Text('Edit'),
                  ),
                  if (showDelete)
                    IconButton(
                      icon: Icon(Icons.delete_outline, color: context.crmColors.destructive),
                      tooltip: 'Delete User',
                      onPressed: onDelete,
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MobileUserCard extends StatelessWidget {
  const _MobileUserCard({
    required this.user,
    required this.currentUserId,
    required this.showDelete,
    required this.onEdit,
    required this.onDelete,
  });

  final CrmUser user;
  final String currentUserId;
  final bool showDelete;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final crmColors = context.crmColors;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: crmColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(user.name, style: Theme.of(context).textTheme.titleMedium),
          6.h,
          Text(
            user.email,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: crmColors.textSecondary,
                ),
          ),
          12.h,
          Row(
            children: [
              Expanded(child: Text('Role: ${user.role}')),
              _StatusChip(active: user.active),
            ],
          ),
          12.h,
          Row(
            children: [
              if (user.id == currentUserId) const Chip(label: Text('You')),
              const Spacer(),
              if (showDelete) ...[
                IconButton(
                  icon: Icon(Icons.delete_outline, color: crmColors.destructive),
                  onPressed: onDelete,
                ),
                const SizedBox(width: 8),
              ],
              OutlinedButton(
                onPressed: onEdit,
                child: const Text('Edit'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.active});

  final bool active;

  @override
  Widget build(BuildContext context) {
    final crmColors = context.crmColors;
    final background = active
        ? crmColors.success.withValues(alpha: 0.12)
        : crmColors.destructive.withValues(alpha: 0.12);
    final foreground = active ? crmColors.success : crmColors.destructive;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        active ? 'Active' : 'Inactive',
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: foreground,
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}

/// Single-line dropdown entry used in the Role dropdown.
/// Must stay one line — DropdownMenuItem constrains height to 24 px.
class _RoleItem extends StatelessWidget {
  const _RoleItem({
    required this.label,
    required this.sub,
    required this.color,
  });

  final String label;
  final String sub;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          margin: const EdgeInsets.only(right: 8),
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: label,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '  $sub',
                style: const TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ],
          ),
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}

/// Compact role chip shown in the users table.
class _RoleBadge extends StatelessWidget {
  const _RoleBadge({required this.role});
  final String role;

  static const _meta = {
    'admin': ('Admin', Colors.deepPurple),
    'manager': ('Manager', Colors.indigo),
    'crm': ('CRM', Colors.blue),
    'sales': ('Sales', Colors.teal),
    'artist': ('Artist', Colors.orange),
    'accounts': ('Accounts', Colors.green),
    'fleet_manager': ('Fleet Manager', Colors.blueGrey),
  };

  @override
  Widget build(BuildContext context) {
    final entry = _meta[role];
    final label = entry?.$1 ?? role;
    final color = entry?.$2 ?? Colors.grey;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}


/// Stable dot colour per role — known keys keep their familiar colour and
/// custom roles get a deterministic one derived from the key.
Color _roleColor(String key) {
  const known = {
    'admin': Colors.deepPurple,
    'manager': Colors.indigo,
    'crm': Colors.blue,
    'sales': Colors.teal,
    'artist': Colors.orange,
    'accounts': Colors.green,
    'fleet_manager': Colors.blueGrey,
    'driver': Colors.brown,
    'inventory_manager': Colors.pink,
    'marketing_admin': Colors.indigo,
  };
  if (known.containsKey(key)) return known[key]!;
  const palette = [
    Colors.cyan, Colors.amber, Colors.purple,
    Colors.redAccent, Colors.lightGreen, Colors.deepOrange,
  ];
  return palette[key.hashCode.abs() % palette.length];
}
