import 'package:dio/dio.dart';
import 'package:nizan_crm/features/accounts/data/artist_expense.dart';

class ExpenseService {
  final Dio _dio;

  ExpenseService(this._dio);

  Future<List<ArtistExpense>> getExpenses({
    String? status,
    String? employeeId,
    String? bookingId,
  }) async {
    try {
      final Map<String, dynamic> query = {};
      if (status != null) query['status'] = status;
      if (employeeId != null) query['employeeId'] = employeeId;
      if (bookingId != null) query['bookingId'] = bookingId;

      final response = await _dio.get(
        '/expenses',
        queryParameters: query.isNotEmpty ? query : null,
      );
      final data = response.data as List;
      return data
          .map((item) => ArtistExpense.fromJson(item as Map<String, dynamic>))
          .toList();
    } on DioException catch (e) {
      throw Exception('Failed to load expenses: ${e.message}');
    }
  }

  Future<ArtistExpense> createExpense({
    required String employeeId,
    String? bookingId,
    required String category,
    required double amount,
    required DateTime date,
    String notes = '',
    String receiptImage = '',
    String workType = 'bridal',
  }) async {
    try {
      final payload = {
        'employeeId': employeeId,
        if (bookingId != null && bookingId.isNotEmpty) 'bookingId': bookingId,
        'category': category,
        'workType': workType,
        'amount': amount,
        'date': date.toIso8601String(),
        'notes': notes,
        'receiptImage': receiptImage,
      };
      final response = await _dio.post('/expenses', data: payload);
      return ArtistExpense.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      final data = e.response?.data;
      throw Exception(
        (data is Map && data['message'] != null)
            ? data['message'].toString()
            : 'Failed to create expense: ${e.message}',
      );
    }
  }

  /// Edits an existing expense. The backend rejects this for an artist once
  /// Accounts has verified or rejected the entry.
  Future<ArtistExpense> updateExpense({
    required String id,
    String? bookingId,
    String? category,
    double? amount,
    DateTime? date,
    String? notes,
    String? receiptImage,
    String? workType,
  }) async {
    try {
      final response = await _dio.put('/expenses/$id', data: {
        'workType': ?workType,
        'bookingId': ?bookingId,
        'category': ?category,
        'amount': ?amount,
        'date': ?date?.toIso8601String(),
        'notes': ?notes,
        'receiptImage': ?receiptImage,
      });
      return ArtistExpense.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      final data = e.response?.data;
      throw Exception(
        (data is Map && data['message'] != null)
            ? data['message'].toString()
            : 'Failed to update expense: ${e.message}',
      );
    }
  }

  Future<ArtistExpense> verifyExpense({
    required String id,
    required String status, // 'verified' | 'rejected'
    required String verifiedBy,
  }) async {
    try {
      final response = await _dio.put(
        '/expenses/$id/verify',
        data: {'status': status, 'verifiedBy': verifiedBy},
      );
      return ArtistExpense.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw Exception('Failed to verify expense: ${e.message}');
    }
  }

  Future<void> deleteExpense(String id) async {
    try {
      await _dio.delete('/expenses/$id');
    } on DioException catch (e) {
      throw Exception('Failed to delete expense: ${e.message}');
    }
  }
}
